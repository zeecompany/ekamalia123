<div class="container py-4">
  <h1 class="h4 fw-bold mb-4"><i class="fa-solid fa-basket-shopping me-2 text-success"></i><?= e(t('cart.title')) ?></h1>
  <?php if (!$groups): ?>
    <div class="ek-empty"><i class="fa-solid fa-cart-shopping"></i><h5><?= e(t('cart.empty')) ?></h5>
      <a class="btn btn-ek rounded-pill px-4" href="<?= url('/products') ?>">Start Shopping</a></div>
  <?php else: ?>
  <div class="row g-4">
    <div class="col-lg-8">
      <?php foreach ($groups as $g): ?>
      <div class="ek-card p-3 mb-3">
        <div class="d-flex align-items-center gap-2 px-2 py-1 mb-2">
          <i class="fa-solid fa-store text-success"></i>
          <a class="fw-bold small" href="<?= url('/shop/' . $g['shop_slug']) ?>"><?= e($g['shop_name']) ?></a>
        </div>
        <?php foreach ($g['items'] as $it): ?>
        <div class="cart-line" data-cart-row="<?= $it['product_id'] ?>">
          <img src="<?= e(img_or($it['image'] ?? '')) ?>" alt="">
          <div class="flex-grow-1 min-w-0">
            <a class="small fw-semibold d-block text-truncate" href="<?= url('/product/' . $it['slug']) ?>"><?= e($it['name']) ?></a>
            <div class="text-muted" style="font-size:.74rem"><?= money($it['unit_price']) ?> × <?= (int)$it['quantity'] ?> = <b class="text-dark"><?= money($it['line_total']) ?></b></div>
            <div class="d-flex align-items-center gap-2 mt-1">
              <button class="qty-btn" data-cart-qty="-1" aria-label="Decrease">−</button>
              <input class="ci-qty form-control form-control-sm text-center" style="width:56px" value="<?= (int)$it['quantity'] ?>" readonly aria-label="Quantity">
              <button class="qty-btn" data-cart-qty="1" aria-label="Increase">+</button>
              <button class="btn btn-link btn-sm text-danger p-0 ms-2" data-cart-remove="<?= $it['product_id'] ?>"><i class="fa-regular fa-trash-can"></i></button>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
        <div class="d-flex justify-content-between px-2 pt-2 small"><span class="text-muted">Subtotal (this shop)</span><b><?= money($g['subtotal']) ?></b></div>
      </div>
      <?php endforeach; ?>
      <div class="text-muted small"><i class="fa-solid fa-circle-info me-1"></i>Items from different shops are split into separate sub-orders automatically — each seller delivers their own items.</div>
    </div>
    <div class="col-lg-4">
      <div class="ek-card p-4 position-sticky" style="top:90px">
        <h5 class="fw-bold mb-3">Order Summary</h5>
        <div class="d-flex justify-content-between small mb-1"><span class="text-muted"><?= e(t('cart.subtotal')) ?></span><b><?= money($totals['subtotal']) ?></b></div>
        <div class="d-flex justify-content-between small mb-1"><span class="text-muted"><?= e(t('cart.shipping')) ?></span><b><?= $totals['shipping'] > 0 ? money($totals['shipping']) : 'FREE' ?></b></div>
        <?php if ($totals['discount'] > 0): ?><div class="d-flex justify-content-between small mb-1 text-success"><span><?= e(t('cart.discount')) ?> (<?= e($totals['coupon']) ?>)</span><b>-<?= money($totals['discount']) ?></b></div><?php endif; ?>
        <hr>
        <div class="d-flex justify-content-between mb-3"><span class="fw-bold"><?= e(t('cart.total')) ?></span><span class="fw-bold fs-5 text-success"><?= money($totals['total']) ?></span></div>
        <div class="input-group mb-2">
          <input class="form-control" id="couponInput" placeholder="<?= e(t('cart.coupon')) ?>" value="<?= e($totals['coupon'] ?? '') ?>">
          <button class="btn btn-outline-success" id="applyCoupon"><?= e(t('cart.apply')) ?></button>
        </div>
        <?php if ($totals['coupon']): ?><button class="btn btn-link btn-sm text-danger p-0 mb-2" id="removeCoupon">Remove coupon</button><?php endif; ?>
        <a class="btn btn-ek btn-lg w-100 rounded-pill mt-2" href="<?= url('/checkout') ?>"><?= e(t('cart.checkout')) ?> <i class="fa-solid fa-arrow-right ms-1"></i></a>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>
