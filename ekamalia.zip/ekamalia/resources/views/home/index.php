<?php
/** Homepage — sections order controlled from Admin > Homepage Builder */
$enabled = array_column($sections, 'is_enabled', 'section_key');
$on = fn($k) => in_array($k, array_column($sections, 'section_key'), true); // exists
$enabledKeys = [];
foreach ($sections as $s) if ($s['is_enabled']) $enabledKeys[] = $s['section_key'];
$show = fn($k) => in_array($k, $enabledKeys, true);
$sectionTitle = [];
foreach ($sections as $s) $sectionTitle[$s['section_key']] = $s['title'];
$placeholder = asset('img/placeholder.svg');
?>
<?php if ($show('hero_slider') && $sliders): ?>
<section class="ek-hero">
  <div class="swiper heroSwiper">
    <div class="swiper-wrapper">
      <?php foreach ($sliders as $s): ?>
      <div class="swiper-slide ek-hero-slide" data-anim="<?= e($s['animation']) ?>">
        <img class="slide-bg" src="<?= e(str_starts_with($s['image'], 'assets/') ? asset($s['image']) : upload_url($s['image'])) ?>" alt="<?= e($s['title'] ?? 'eKamalia') ?>" fetchpriority="high">
        <div class="slide-veil"></div>
        <div class="slide-content">
          <h2><?= e($s['title']) ?></h2>
          <p><?= e($s['subtitle']) ?></p>
          <?php if ($s['button_text']): ?><a class="btn btn-slide mt-2" href="<?= e(str_starts_with($s['button_url'] ?? '', 'http') ? $s['button_url'] : url($s['button_url'] ?? '/')) ?>"><?= e($s['button_text']) ?> <i class="fa-solid fa-arrow-right ms-1"></i></a><?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="swiper-pagination"></div>
  </div>
</section>
<?php endif; ?>

<?php if ($show('quick_actions')): ?>
<section class="ek-section pb-0">
  <div class="container">
    <div class="row g-2 g-md-3 row-cols-3 row-cols-md-5">
      <?php
      $quick = [
        ['Post an Ad', 'fa-circle-plus', 'qa-1', '/ads/create'], ['Find Products', 'fa-bag-shopping', 'qa-2', '/products'],
        ['Find Shops', 'fa-store', 'qa-3', '/shops'], ['Find Services', 'fa-screwdriver-wrench', 'qa-4', '/category/services'],
        ['Find Jobs', 'fa-briefcase', 'qa-5', '/category/jobs'], ['Property', 'fa-house-chimney', 'qa-6', '/category/property'],
        ['Vehicles', 'fa-car-side', 'qa-7', '/category/vehicles'], ['Electronics', 'fa-tv', 'qa-8', '/category/electronics'],
        ['Businesses', 'fa-map-location-dot', 'qa-9', '/businesses'], ['Explore Kamalia', 'fa-city', 'qa-10', '/explore-kamalia'],
      ];
      foreach ($quick as $q): ?>
        <div class="col"><a class="ek-qa-card <?= $q[2] ?>" href="<?= url($q[3]) ?>"><i class="fa-solid <?= $q[1] ?>"></i><?= e($q[0]) ?></a></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<div class="container">
  <?php if ($show('marquee_offers')):
      $offers = qa('SELECT text,url FROM marquees WHERE status="active" AND type="offer" AND (start_date IS NULL OR start_date<=CURDATE()) AND (end_date IS NULL OR end_date>=CURDATE()) ORDER BY sort_order LIMIT 8');
      if ($offers): $items = array_merge($offers, $offers); ?>
  <section class="mt-4">
    <div class="ek-offers-bar" role="marquee" aria-label="Offers">
      <div class="mq-track">
        <?php foreach ($items as $o): ?>
          <span class="mq-item"><i class="fa-solid fa-gift"></i> <?php if ($o['url']): ?><a href="<?= e(str_starts_with($o['url'], 'http') ? $o['url'] : url($o['url'])) ?>" class="text-decoration-none" style="color:#4d3700"><?= e($o['text']) ?></a><?php else: ?><?= e($o['text']) ?><?php endif; ?> <span style="opacity:.4">•</span></span>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>
  <?php endif; ?>

  <?php if ($banner): ?>
  <section class="mt-4">
    <a href="<?= url('/ad-click/' . $banner['id']) ?>" target="_blank" rel="noopener" class="d-block rounded-4 overflow-hidden">
      <img src="<?= e(upload_url($banner['image'])) ?>" class="w-100" style="max-height:170px;object-fit:cover" alt="<?= e($banner['title']) ?>" loading="lazy"></a>
  </section>
  <?php endif; ?>

  <?php if ($show('categories')): ?>
  <section class="ek-section" id="categories">
    <div class="ek-section-head">
      <h2><?= e($sectionTitle['categories'] ?? 'Browse Categories') ?></h2>
      <a class="ek-link-all" href="<?= url('/categories') ?>">All categories <i class="fa-solid fa-angle-right"></i></a>
    </div>
    <div class="row g-2 g-md-3 row-cols-3 row-cols-md-4 row-cols-lg-6">
      <?php foreach (array_slice($cats, 0, 18) as $c): ?>
        <div class="col reveal">
          <a class="ek-cat-card" href="<?= url('/category/' . $c['slug']) ?>">
            <div class="ic"><i class="fa-solid <?= e($c['icon'] ?: 'fa-tag') ?>"></i></div>
            <div class="nm"><?= e($c['name']) ?></div>
            <div class="text-muted" style="font-size:.66rem"><?= number_format((int)$c['ads_count']) ?> listings</div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($show('bijli_updates')): ?>
  <?php $offCount = count(array_filter($feeders, fn($f) => ($f['status'] ?? 'on') !== 'on')); ?>
  <section class="ek-section" style="background:linear-gradient(180deg,#fff8e6,#fdf6e3 70%,transparent);border-radius:26px">
    <div class="ek-section-head">
      <h2><i class="fa-solid fa-bolt text-warning me-1"></i> <?= e($sectionTitle['bijli_updates'] ?? 'Bijli Updates') ?></h2>
      <div class="d-flex align-items-center gap-3">
        <?php if ($offCount > 0): ?><span class="badge text-bg-danger"><?= $offCount ?> feeder<?= $offCount > 1 ? 's' : '' ?> OFF now</span>
        <?php else: ?><span class="badge text-bg-success">All feeders ON</span><?php endif; ?>
        <a class="ek-link-all" href="<?= url('/bijli') ?>">Live status <i class="fa-solid fa-angle-right"></i></a>
      </div>
    </div>
    <div class="row g-3 row-cols-1 row-cols-md-2 row-cols-lg-4">
      <?php foreach (array_slice($feeders, 0, 4) as $f): ?>
        <div class="col reveal"><?php include views_path('partials/bijli-card'); ?></div>
      <?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($show('featured_ads') && $ads): ?>
  <section class="ek-section">
    <div class="ek-section-head">
      <h2><?= e($sectionTitle['featured_ads'] ?? 'Fresh & Featured Ads') ?></h2>
      <a class="ek-link-all" href="<?= url('/ads') ?>">View all ads <i class="fa-solid fa-angle-right"></i></a>
    </div>
    <div class="swiper rowSwiper pb-4">
      <div class="swiper-wrapper">
        <?php foreach ($ads as $a): ?><div class="swiper-slide h-auto"><?php include views_path('partials/ad-card'); ?></div><?php endforeach; ?>
      </div>
      <div class="swiper-button-next"></div><div class="swiper-button-prev"></div>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($show('featured_products') && $products): ?>
  <section class="ek-section pt-0">
    <div class="ek-section-head">
      <h2><?= e($sectionTitle['featured_products'] ?? 'Featured Products') ?></h2>
      <a class="ek-link-all" href="<?= url('/products') ?>">Shop all <i class="fa-solid fa-angle-right"></i></a>
    </div>
    <div class="swiper rowSwiper pb-4">
      <div class="swiper-wrapper">
        <?php foreach ($products as $p): ?><div class="swiper-slide h-auto"><?php include views_path('partials/product-card'); ?></div><?php endforeach; ?>
      </div>
      <div class="swiper-button-next"></div><div class="swiper-button-prev"></div>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($show('deals') && $deals): ?>
  <section class="ek-section pt-0">
    <div class="ek-section-head">
      <h2><i class="fa-solid fa-percent text-danger me-1"></i> <?= e($sectionTitle['deals'] ?? 'Deals & Offers') ?></h2>
      <a class="ek-link-all" href="<?= url('/deals') ?>">All deals <i class="fa-solid fa-angle-right"></i></a>
    </div>
    <div class="swiper rowSwiper pb-4">
      <div class="swiper-wrapper">
        <?php foreach ($deals as $p): ?><div class="swiper-slide h-auto"><?php include views_path('partials/product-card'); ?></div><?php endforeach; ?>
      </div>
      <div class="swiper-button-next"></div><div class="swiper-button-prev"></div>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($show('featured_shops') && $shops): ?>
  <section class="ek-section pt-0">
    <div class="ek-section-head">
      <h2><?= e($sectionTitle['featured_shops'] ?? 'Featured Shops') ?></h2>
      <a class="ek-link-all" href="<?= url('/shops') ?>">All shops <i class="fa-solid fa-angle-right"></i></a>
    </div>
    <div class="swiper shopSwiper pb-4">
      <div class="swiper-wrapper">
        <?php foreach (array_slice($shops, 0, 8) as $s): ?><div class="swiper-slide h-auto"><?php include views_path('partials/shop-card'); ?></div><?php endforeach; ?>
      </div>
      <div class="swiper-button-next"></div><div class="swiper-button-prev"></div>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($show('business_directory') && $businesses): ?>
  <section class="ek-section pt-0">
    <div class="ek-section-head">
      <h2><?= e($sectionTitle['business_directory'] ?? 'Kamalia Business Directory') ?></h2>
      <div class="d-flex gap-2">
        <a class="ek-link-all" href="<?= url('/businesses') ?>">Full directory <i class="fa-solid fa-angle-right"></i></a>
        <a class="btn btn-sm btn-outline-success rounded-pill px-3" href="<?= url('/businesses/create') ?>"><i class="fa-solid fa-plus me-1"></i>List your business</a>
      </div>
    </div>
    <div class="row g-3 row-cols-1 row-cols-md-2">
      <?php foreach ($businesses as $b): ?><div class="col"><?php include views_path('partials/business-card'); ?></div><?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($show('news') && $news): ?>
  <section class="ek-section pt-0">
    <div class="ek-section-head"><h2><?= e($sectionTitle['news'] ?? 'Kamalia News & Updates') ?></h2>
      <a class="ek-link-all" href="<?= url('/news') ?>">All news <i class="fa-solid fa-angle-right"></i></a></div>
    <div class="row g-4 row-cols-1 row-cols-md-3">
      <?php foreach ($news as $n): ?>
      <div class="col reveal">
        <a class="ek-card d-block h-100 overflow-hidden" href="<?= url('/news/' . $n['slug']) ?>">
          <img src="<?= e($n['image'] ? upload_url($n['image']) : asset('img/news-default.svg')) ?>" class="w-100" style="height:170px;object-fit:cover" alt="" loading="lazy">
          <div class="p-3">
            <div class="text-muted" style="font-size:.7rem"><i class="fa-regular fa-clock me-1"></i><?= e(time_ago($n['published_at'])) ?></div>
            <div class="fw-bold mt-1" style="font-size:.92rem"><?= e($n['title']) ?></div>
            <div class="text-muted mt-1" style="font-size:.8rem"><?= e(mb_substr(strip_tags((string)$n['excerpt']), 0, 90)) ?>…</div>
          </div>
        </a>
      </div>
      <?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($show('testimonials') && $testimonials): ?>
  <section class="ek-section pt-0">
    <div class="ek-section-head"><h2><?= e($sectionTitle['testimonials'] ?? 'What Kamalia Says') ?></h2></div>
    <div class="row g-3 row-cols-1 row-cols-md-3">
      <?php foreach ($testimonials as $tt): ?>
      <div class="col reveal">
        <div class="ek-card p-3 h-100">
          <div class="stars mb-2"><?php for ($i = 1; $i <= 5; $i++): ?><i class="fa-<?= $i <= $tt['rating'] ? 'solid' : 'regular' ?> fa-star"></i><?php endfor; ?></div>
          <p class="mb-2" style="font-size:.88rem">“<?= e($tt['comment']) ?>”</p>
          <div class="d-flex align-items-center gap-2">
            <img src="<?= e($tt['photo'] ? upload_url($tt['photo']) : asset('img/avatar-default.svg')) ?>" style="width:36px;height:36px;border-radius:50%;object-fit:cover" alt="" loading="lazy">
            <div><div class="fw-bold small"><?= e($tt['name']) ?></div>
            <?php if ($tt['business']): ?><div class="text-muted" style="font-size:.7rem"><?= e($tt['business']) ?></div><?php endif; ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($show('cta')): ?>
  <section class="ek-section pt-0">
    <div class="rounded-4 p-4 p-md-5 text-center text-white" style="background:var(--ek-gradient);box-shadow:var(--ek-shadow-lg)">
      <h2 class="fw-bold mb-2">Apni Dukaan, Apna Bazaar 🇵🇰</h2>
      <p class="mb-4" style="opacity:.92">Join <?= number_format($stats['users']) ?>+ Kamalia members. Post ads free, open your shop, and grow your business.</p>
      <div class="d-flex gap-2 justify-content-center flex-wrap">
        <a href="<?= url('/ads/create') ?>" class="btn btn-warning rounded-pill px-4 fw-bold">Post Free Ad</a>
        <a href="<?= url('/shops/create') ?>" class="btn btn-outline-light rounded-pill px-4 fw-semibold">Create Your Shop</a>
        <a href="<?= url('/pos/request') ?>" class="btn btn-outline-light rounded-pill px-4 fw-semibold">Premium POS</a>
      </div>
      <div class="d-flex gap-4 justify-content-center flex-wrap mt-4 small">
        <span><b class="ek-counter" data-count="<?= $stats['ads'] ?>">0</b>+ Live Ads</span>
        <span><b class="ek-counter" data-count="<?= $stats['products'] ?>">0</b>+ Products</span>
        <span><b class="ek-counter" data-count="<?= $stats['shops'] ?>">0</b>+ Shops</span>
        <span><b class="ek-counter" data-count="<?= $stats['users'] ?>">0</b>+ Members</span>
      </div>
    </div>
  </section>
  <?php endif; ?>
</div>
