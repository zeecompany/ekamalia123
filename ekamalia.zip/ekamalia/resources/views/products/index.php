<div class="container py-4" id="results">
  <nav aria-label="breadcrumb" class="ek-breadcrumb">
    <ol class="breadcrumb"><li class="breadcrumb-item"><a href="<?= url('/') ?>">Home</a></li>
    <li class="breadcrumb-item active"><?= e($dealsOnly ? 'Deals & Offers' : ($cat['name'] ?? 'Products')) ?></li></ol>
  </nav>
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h4 fw-bold mb-0"><?= $dealsOnly ? '🔥 Deals & Offers' : e($cat['name'] ?? 'Product Marketplace') ?></h1>
    <a class="btn btn-outline-secondary rounded-pill btn-sm" href="<?= url('/compare') ?>"><i class="fa-solid fa-scale-balanced me-1"></i>Compare (<?= count($_SESSION['compare'] ?? []) ?>)</a>
  </div>
  <div class="row g-4">
    <aside class="col-lg-3">
      <form class="ek-card p-3 filter-card" method="get">
        <h6 class="fw-bold mb-3"><i class="fa-solid fa-filter me-1"></i> Filters</h6>
        <div class="mb-3"><label class="form-label">Keyword</label><input type="text" class="form-control" name="q" value="<?= e($_GET['q'] ?? '') ?>"></div>
        <div class="mb-3"><label class="form-label">City</label>
          <select class="form-select" name="city"><option value="">All cities</option>
          <?php foreach (qa('SELECT * FROM cities WHERE is_active=1 ORDER BY is_primary DESC, sort_order') as $c): ?>
            <option value="<?= e($c['slug']) ?>" <?= ($_GET['city'] ?? '') === $c['slug'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
          <?php endforeach; ?></select></div>
        <div class="mb-3"><label class="form-label">Brand</label>
          <select class="form-select" name="brand"><option value="">All brands</option>
          <?php foreach ($brands as $b): ?><option value="<?= $b['id'] ?>" <?= ($_GET['brand'] ?? '') == $b['id'] ? 'selected' : '' ?>><?= e($b['name']) ?></option><?php endforeach; ?></select></div>
        <div class="row g-2 mb-3">
          <div class="col-6"><label class="form-label">Min Rs</label><input type="number" class="form-control" name="min_price" value="<?= e($_GET['min_price'] ?? '') ?>"></div>
          <div class="col-6"><label class="form-label">Max Rs</label><input type="number" class="form-control" name="max_price" value="<?= e($_GET['max_price'] ?? '') ?>"></div>
        </div>
        <div class="mb-3"><label class="form-label">Sort</label>
          <select class="form-select" name="sort">
            <option value="newest" <?= ($_GET['sort'] ?? '') === 'newest' ? 'selected' : '' ?>>Newest</option>
            <option value="price_low" <?= ($_GET['sort'] ?? '') === 'price_low' ? 'selected' : '' ?>>Price ↑</option>
            <option value="price_high" <?= ($_GET['sort'] ?? '') === 'price_high' ? 'selected' : '' ?>>Price ↓</option>
            <option value="popular" <?= ($_GET['sort'] ?? '') === 'popular' ? 'selected' : '' ?>>Popular</option>
            <option value="rating" <?= ($_GET['sort'] ?? '') === 'rating' ? 'selected' : '' ?>>Best rated</option>
          </select></div>
        <button class="btn btn-ek w-100 rounded-pill">Apply</button>
      </form>
    </aside>
    <div class="col-lg-9">
      <p class="text-muted small mb-3"><?= number_format($total) ?> products found</p>
      <?php if ($subcats): ?>
      <div class="d-flex flex-wrap gap-2 mb-3">
        <?php foreach ($subcats as $sc): ?><a class="chip" href="?<?= e(http_build_query(array_merge($_GET, ['cat' => $sc['id']]))) ?>"><?= e($sc['name']) ?> (<?= (int)$sc['cnt'] ?>)</a><?php endforeach; ?>
      </div>
      <?php endif; ?>
      <?php if ($products): ?>
      <div class="row g-3 row-cols-2 row-cols-md-3 row-cols-xl-4">
        <?php foreach ($products as $p): ?><div class="col"><?php include views_path('partials/product-card'); ?></div><?php endforeach; ?>
      </div>
      <div class="mt-4"><?= paginate($total, $perPage) ?></div>
      <?php else: ?>
      <div class="ek-empty"><i class="fa-solid fa-box-open"></i><h5>No products found</h5><p class="small">Check back soon — Kamalia shops are adding products daily.</p></div>
      <?php endif; ?>
    </div>
  </div>
</div>
