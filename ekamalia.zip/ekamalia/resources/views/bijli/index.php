<div class="container py-4">
  <div class="text-center mb-4">
    <div class="d-inline-flex align-items-center gap-2 badge rounded-pill text-bg-warning bg-gradient px-3 py-2 mb-2"><i class="fa-solid fa-bolt"></i> LIVE • Updated by eKamalia team</div>
    <h1 class="h3 fw-bold mb-1">⚡ <?= e(t('bijli.title')) ?></h1>
    <p class="text-muted mb-0"><?= e(t('bijli.subtitle')) ?></p>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-md-4"><div class="kpi-card"><div class="ic ic-red"><i class="fa-solid fa-plug-circle-xmark"></i></div><div><div class="val"><?= $offCount ?></div><div class="lbl">Feeders OFF right now</div></div></div></div>
    <div class="col-md-4"><div class="kpi-card"><div class="ic ic-green"><i class="fa-solid fa-lightbulb"></i></div><div><div class="val"><?= count($feeders) - $offCount ?></div><div class="lbl">Feeders ON</div></div></div></div>
    <div class="col-md-4"><div class="kpi-card"><div class="ic ic-gold"><i class="fa-solid fa-tower-broadcast"></i></div><div><div class="val"><?= count($feeders) ?></div><div class="lbl">Monitored feeders (Kamalia + surroundings)</div></div></div></div>
  </div>

  <div class="d-flex flex-wrap gap-2 mb-4">
    <a class="chip <?= !$activeCity && !input('feeder') ? 'active' : '' ?>" href="<?= url('/bijli') ?>">All areas</a>
    <?php foreach ($cities as $c): ?>
      <a class="chip <?= ($activeCity && $activeCity['id'] == $c['id']) ? 'active' : '' ?>" href="<?= url('/bijli?city=' . $c['slug']) ?>"><i class="fa-solid fa-location-dot me-1"></i><?= e($c['name']) ?> <span class="opacity-50">(<?= (int)$c['feeder_count'] ?>)</span></a>
    <?php endforeach; ?>
  </div>

  <div class="row g-4">
    <div class="col-lg-7">
      <h5 class="fw-bold mb-3"><i class="fa-solid fa-gauge-high me-1"></i>Feeder Status</h5>
      <div id="bijliLive" class="d-flex flex-column gap-2">
        <?php foreach ($feeders as $f): include views_path('partials/bijli-card'); endforeach; ?>
        <?php if (!$feeders): ?><div class="ek-empty"><i class="fa-solid fa-plug"></i><p>No feeders monitored for this area yet.</p></div><?php endif; ?>
      </div>
      <div class="text-muted small mt-2"><i class="fa-solid fa-rotate me-1"></i>Auto-refreshes every 60 seconds</div>

      <div class="ek-card p-4 mt-4">
        <h5 class="fw-bold mb-3"><i class="fa-solid fa-bullhorn me-1 text-danger"></i><?= e(t('bijli.report')) ?></h5>
        <?php if (auth()): ?>
        <form id="bijliReportForm">
          <div class="row g-2">
            <div class="col-md-5"><select class="form-select" id="brFeeder" required>
              <option value="">Select feeder</option>
              <?php foreach ($feeders as $f): ?><option value="<?= $f['id'] ?>"><?= e($f['name']) ?></option><?php endforeach; ?></select></div>
            <div class="col-md-7"><input class="form-control" id="brMsg" placeholder="e.g. Bijli gayi hai 30 min se — Chak 341" required maxlength="300"></div>
          </div>
          <button class="btn btn-outline-danger rounded-pill px-4 mt-2 btn-sm"><i class="fa-solid fa-paper-plane me-1"></i>Send Report</button>
        </form>
        <?php else: ?>
        <a class="btn btn-outline-success rounded-pill px-4 btn-sm" href="<?= url('/login') ?>">Login to report an outage — help your neighbors!</a>
        <?php endif; ?>
      </div>
    </div>

    <div class="col-lg-5">
      <h5 class="fw-bold mb-3"><i class="fa-regular fa-clock me-1"></i>Latest Updates</h5>
      <div class="ek-card p-3" style="max-height:640px;overflow:auto">
        <?php foreach ($updates as $u):
            $cls = ['on' => 'success', 'off' => 'danger', 'maintenance' => 'warning', 'scheduled' => 'info'][$u['status']] ?? 'secondary';
            $icon = ['on' => 'fa-plug-circle-check', 'off' => 'fa-plug-circle-xmark', 'maintenance' => 'fa-screwdriver-wrench', 'scheduled' => 'fa-clock'][$u['status']] ?? 'fa-bolt'; ?>
        <div class="d-flex gap-2 py-2 border-bottom">
          <span class="badge text-bg-<?= $cls ?> align-self-start" style="min-width:86px"><i class="fa-solid <?= $icon ?> me-1"></i><?= strtoupper($u['status']) ?></span>
          <div class="min-w-0">
            <div class="fw-semibold small"><?= e($u['feeder_name']) ?> <span class="text-muted fw-normal">• <?= e($u['city_name']) ?></span></div>
            <?php if ($u['title']): ?><div class="small"><?= e($u['title']) ?></div><?php endif; ?>
            <?php if ($u['message']): ?><div class="text-muted" style="font-size:.76rem"><?= e($u['message']) ?></div><?php endif; ?>
            <div class="text-muted" style="font-size:.66rem"><i class="fa-regular fa-clock me-1"></i><?= e(fmt_date($u['created_at'])) ?><?= $u['expected_at'] ? ' • expected back ' . e(fmt_date($u['expected_at'], 'h:i A')) : '' ?></div>
          </div>
        </div>
        <?php endforeach; ?>
        <?php if (!$updates): ?><p class="text-muted small text-center py-3 mb-0">No updates yet.</p><?php endif; ?>
      </div>
    </div>
  </div>
</div>
<script>
const brf = document.getElementById('bijliReportForm');
brf && brf.addEventListener('submit', e => {
  e.preventDefault();
  ekPost('<?= url('/bijli/report') ?>', { feeder_id: document.getElementById('brFeeder').value, message: document.getElementById('brMsg').value })
    .then(r => { toast(r.message, r.ok ? 'success' : 'danger'); if (r.ok) document.getElementById('brMsg').value = ''; });
});
</script>
