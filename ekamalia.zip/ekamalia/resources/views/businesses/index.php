<div class="container py-4">
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <div>
      <h1 class="h4 fw-bold mb-0"><i class="fa-solid fa-map-location-dot me-2 text-success"></i>Kamalia Business Directory</h1>
      <p class="text-muted small mb-0">Restaurants, clinics, schools, mechanics, shops &amp; services across Kamalia and Toba Tek Singh.</p>
    </div>
    <a class="btn btn-ek rounded-pill px-4" href="<?= url('/businesses/create') ?>"><i class="fa-solid fa-plus me-1"></i>List Your Business</a>
  </div>
  <div class="d-flex flex-wrap gap-2 mb-4">
    <a class="chip <?= !input('cat') ? 'active' : '' ?>" href="?<?= e(http_build_query(array_diff_key($_GET, ['cat' => 1]))) ?>">All</a>
    <?php foreach ($cats as $c): ?>
      <a class="chip <?= input('cat') == $c['id'] ? 'active' : '' ?>" href="?<?= e(http_build_query(array_merge($_GET, ['cat' => $c['id']]))) ?>"><i class="fa-solid fa-briefcase me-1"></i><?= e($c['name']) ?> (<?= (int)$c['cnt'] ?>)</a>
    <?php endforeach; ?>
  </div>
  <form class="row g-2 mb-4" method="get">
    <input type="hidden" name="cat" value="<?= e((string)input('cat')) ?>">
    <div class="col-md-5"><input class="form-control" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Search businesses…"></div>
    <div class="col-md-4"><select class="form-select" name="city"><option value="">All cities</option>
      <?php foreach (qa('SELECT * FROM cities WHERE is_active=1 ORDER BY is_primary DESC, sort_order') as $c): ?>
        <option value="<?= e($c['slug']) ?>" <?= ($_GET['city'] ?? '') === $c['slug'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
      <?php endforeach; ?></select></div>
    <div class="col-md-3"><button class="btn btn-ek w-100 rounded-pill">Search</button></div>
  </form>
  <?php if ($businesses): ?>
  <div class="row g-3"><?= implode('', array_map(fn() => '', [])) ?><?php foreach ($businesses as $b): ?><div class="col-md-6"><?php include views_path('partials/business-card'); ?></div><?php endforeach; ?></div>
  <div class="mt-4"><?= paginate($total, $perPage) ?></div>
  <?php else: ?>
  <div class="ek-empty"><i class="fa-solid fa-store-slash"></i><h5>No businesses found</h5><p class="small">Know a great Kamalia business? List it free!</p>
    <a class="btn btn-ek rounded-pill px-4" href="<?= url('/businesses/create') ?>">Add Business</a></div>
  <?php endif; ?>
</div>
