<?php $isCatPage = !empty($cat); ?>
<div class="container py-4" id="results">
  <nav aria-label="breadcrumb" class="ek-breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?= url('/') ?>">Home</a></li>
      <li class="breadcrumb-item active"><?= e($cat['name'] ?? 'Classified Ads') ?></li>
    </ol>
  </nav>
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h4 fw-bold mb-0"><?= e($cat['name'] ?? 'Classified Ads in Kamalia') ?></h1>
    <a class="btn btn-ek rounded-pill px-4" href="<?= url('/ads/create') ?>"><i class="fa-solid fa-plus me-1"></i><?= e(t('btn.post_ad')) ?></a>
  </div>

  <?php if ($subcats): ?>
  <div class="d-flex flex-wrap gap-2 mb-3">
    <a class="chip <?= !input('sub') ? 'active' : '' ?>" href="?<?= e(http_build_query(array_diff_key($_GET, ['sub' => 1]))) ?>">All</a>
    <?php foreach ($subcats as $sc): ?>
      <a class="chip <?= input('sub') == $sc['id'] ? 'active' : '' ?>" href="?<?= e(http_build_query(array_merge($_GET, ['sub' => $sc['id']]))) ?>"><?= e($sc['name']) ?> <span class="opacity-50">(<?= (int)$sc['cnt'] ?>)</span></a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <div class="row g-4">
    <aside class="col-lg-3">
      <form class="ek-card p-3 filter-card" method="get">
        <?php if ($isCatPage): ?><input type="hidden" name="keep" value="1"><?php endif; ?>
        <h6 class="fw-bold mb-3"><i class="fa-solid fa-filter me-1"></i> Filters</h6>
        <div class="mb-3">
          <label class="form-label">Keyword</label>
          <input type="text" class="form-control" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="e.g. iPhone">
        </div>
        <div class="mb-3">
          <label class="form-label">City</label>
          <select class="form-select" name="city">
            <option value="">All cities</option>
            <?php foreach (qa('SELECT * FROM cities WHERE is_active=1 ORDER BY is_primary DESC, sort_order') as $c): ?>
              <option value="<?= e($c['slug']) ?>" <?= ($_GET['city'] ?? '') === $c['slug'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="row g-2 mb-3">
          <div class="col-6"><label class="form-label">Min Rs</label><input type="number" class="form-control" name="min_price" value="<?= e($_GET['min_price'] ?? '') ?>" min="0"></div>
          <div class="col-6"><label class="form-label">Max Rs</label><input type="number" class="form-control" name="max_price" value="<?= e($_GET['max_price'] ?? '') ?>" min="0"></div>
        </div>
        <div class="mb-3">
          <label class="form-label">Condition</label>
          <select class="form-select" name="condition">
            <option value="">Any</option>
            <?php foreach (['new' => 'New', 'used' => 'Used', 'refurbished' => 'Refurbished'] as $k => $v): ?>
              <option value="<?= $k ?>" <?= ($_GET['condition'] ?? '') === $k ? 'selected' : '' ?>><?= $v ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-check"><input class="form-check-input" type="checkbox" name="featured" value="1" <?= !empty($_GET['featured']) ? 'checked' : '' ?>><label class="form-check-label small">Featured only</label></div>
        <div class="form-check"><input class="form-check-input" type="checkbox" name="negotiable" value="1" <?= !empty($_GET['negotiable']) ? 'checked' : '' ?>><label class="form-check-label small">Negotiable</label></div>
        <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="delivery" value="1" <?= !empty($_GET['delivery']) ? 'checked' : '' ?>><label class="form-check-label small">Delivery available</label></div>
        <div class="mb-3">
          <label class="form-label">Sort</label>
          <select class="form-select" name="sort">
            <option value="newest" <?= ($_GET['sort'] ?? '') === 'newest' ? 'selected' : '' ?>>Newest first</option>
            <option value="price_low" <?= ($_GET['sort'] ?? '') === 'price_low' ? 'selected' : '' ?>>Price: low to high</option>
            <option value="price_high" <?= ($_GET['sort'] ?? '') === 'price_high' ? 'selected' : '' ?>>Price: high to low</option>
            <option value="popular" <?= ($_GET['sort'] ?? '') === 'popular' ? 'selected' : '' ?>>Most viewed</option>
          </select>
        </div>
        <button class="btn btn-ek w-100 rounded-pill">Apply Filters</button>
      </form>
      <?php if (auth()): ?>
      <form class="ek-card p-3 mt-3" method="post" action="<?= url('/search/save') ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="name" value="<?= e($cat['name'] ?? 'Ads search') ?>">
        <button class="btn btn-outline-success btn-sm w-100 rounded-pill"><i class="fa-regular fa-bell me-1"></i>Save this search</button>
      </form>
      <?php endif; ?>
    </aside>

    <div class="col-lg-9">
      <p class="text-muted small mb-3"><?= number_format($total) ?> ads found</p>
      <?php if ($ads): ?>
      <div class="row g-3 row-cols-2 row-cols-md-3 row-cols-xl-4">
        <?php foreach ($ads as $a): ?><div class="col"><?php include views_path('partials/ad-card'); ?></div><?php endforeach; ?>
      </div>
      <div class="mt-4"><?= paginate($total, $perPage) ?></div>
      <?php else: ?>
      <div class="ek-empty">
        <i class="fa-solid fa-magnifying-glass"></i>
        <h5>No ads found</h5>
        <p class="small">Try different filters — or be the first to post in this category!</p>
        <a class="btn btn-ek rounded-pill px-4" href="<?= url('/ads/create') ?>">Post the first ad</a>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
