<div class="container py-4">
  <nav aria-label="breadcrumb"><ol class="breadcrumb small"><li class="breadcrumb-item"><a href="/">Home</a></li><li class="breadcrumb-item active">All Categories</li></ol></nav>
  <h1 class="h3 fw-bold mb-1">All Categories</h1>
  <p class="text-muted mb-4">Browse everything on eKamalia — <?= e(t('misc.products')) ?> and classified ads across Kamalia &amp; Toba Tek Singh.</p>

  <div class="row g-4">
    <?php foreach ($parents as $c): ?>
    <div class="col-md-6 col-lg-4">
      <div class="ek-card p-4 h-100">
        <div class="d-flex align-items-center gap-3 mb-2">
          <span class="cat-ic" style="width:46px;height:46px;font-size:1.2rem"><i class="<?= e($c['icon'] ?: 'fa-solid fa-tag') ?>"></i></span>
          <div class="flex-grow-1">
            <a class="fw-bold text-decoration-none text-dark" href="<?= url('/category/' . $c['slug']) ?>"><?= e($c['name']) ?></a>
            <div class="text-muted" style="font-size:.72rem"><?= (int)$c['product_count'] ?> products • <?= (int)$c['ad_count'] ?> ads</div>
          </div>
        </div>
        <?php if ($c['children']): ?>
        <div class="d-flex flex-wrap gap-1 mt-3">
          <?php foreach (array_slice($c['children'], 0, 8) as $ch): ?>
          <a class="chip text-decoration-none" href="<?= url('/category/' . $ch['slug']) ?>"><?= e($ch['name']) ?> <span class="opacity-50"><?= (int)$ch['product_count'] + (int)$ch['ad_count'] ?></span></a>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
