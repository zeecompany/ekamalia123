<?php
/** Product card partial. Expects $p (product row with shop_name, image, shop_slug) */
$sale = $p['sale_price'] && (float)$p['sale_price'] > 0 && (float)$p['sale_price'] < (float)$p['price'];
$price = $sale ? (float)$p['sale_price'] : (float)$p['price'];
$disc = $sale ? round(100 - ($price / (float)$p['price'] * 100)) : 0;
?>
<article class="ek-card ek-item-card reveal in">
  <a class="thumb" href="<?= url('/product/' . $p['slug']) ?>" aria-label="<?= e($p['name']) ?>">
    <img src="<?= e(img_or($p['image'] ?? '')) ?>" alt="<?= e($p['name']) ?>" loading="lazy" data-fade>
    <span class="flags">
      <?php if ($p['is_featured']): ?><span class="ek-flag featured"><i class="fa-solid fa-star"></i> Featured</span><?php endif; ?>
      <?php if ($disc > 0): ?><span class="ek-flag discount">-<?= $disc ?>%</span><?php endif; ?>
      <?php if ((int)$p['stock'] <= 0): ?><span class="ek-flag urgent">Out of stock</span><?php endif; ?>
    </span>
  </a>
  <div class="quick">
    <button class="ek-quick-btn heart <?= !empty($p['wishlisted']) ? 'active' : '' ?>" data-wishlist="product" data-id="<?= $p['id'] ?>" aria-label="Wishlist"><i class="fa-solid fa-heart"></i></button>
    <button class="ek-quick-btn" data-share="<?= e(url('/product/' . $p['slug'])) ?>" data-title="<?= e($p['name']) ?>" aria-label="Share"><i class="fa-solid fa-share-nodes"></i></button>
  </div>
  <div class="body">
    <a class="title" href="<?= url('/product/' . $p['slug']) ?>"><?= e($p['name']) ?></a>
    <div class="ek-price"><?= money($price) ?><?php if ($sale): ?><span class="old"><?= money($p['price']) ?></span><?php endif; ?></div>
    <div class="shop-row">
      <?php if (!empty($p['shop_name'])): ?>
        <a href="<?= url('/shop/' . $p['shop_slug']) ?>" class="text-truncate" style="max-width:130px"><i class="fa-solid fa-store me-1"></i><?= e($p['shop_name']) ?></a>
        <?php if (!empty($p['shop_verified'])): ?><i class="fa-solid fa-circle-check verified-tick" title="Verified Shop"></i><?php endif; ?>
      <?php endif; ?>
      <?php if ($p['rating_count'] > 0): ?>
        <span class="stars ms-auto"><i class="fa-solid fa-star"></i> <?= number_format((float)$p['rating_avg'], 1) ?></span>
      <?php endif; ?>
    </div>
    <div class="meta">
      <span><i class="fa-solid fa-location-dot"></i> <?= e($p['city_name'] ?? 'Kamalia') ?></span>
      <button class="btn btn-sm btn-ek rounded-pill px-3 ms-auto" data-cart-add="<?= $p['id'] ?>" <?= (int)$p['stock'] <= 0 ? 'disabled' : '' ?>>
        <i class="fa-solid fa-cart-plus"></i>
      </button>
    </div>
  </div>
</article>
