<?php
/** Ad (classified) card partial. Expects $a */
?>
<article class="ek-card ek-item-card reveal in">
  <a class="thumb" href="<?= url('/ad/' . $a['slug']) ?>" aria-label="<?= e($a['title']) ?>">
    <img src="<?= e(img_or($a['image'] ?? '')) ?>" alt="<?= e($a['title']) ?>" loading="lazy" data-fade>
    <span class="flags">
      <?php if ($a['is_featured']): ?><span class="ek-flag featured"><i class="fa-solid fa-star"></i> Featured</span><?php endif; ?>
      <?php if ($a['is_urgent']): ?><span class="ek-flag urgent">Urgent</span><?php endif; ?>
      <?php if (($a['condition'] ?? '') === 'new'): ?><span class="ek-flag discount">New</span><?php endif; ?>
    </span>
  </a>
  <div class="quick">
    <button class="ek-quick-btn heart <?= !empty($a['wishlisted']) ? 'active' : '' ?>" data-wishlist="ad" data-id="<?= $a['id'] ?>" aria-label="Save ad"><i class="fa-solid fa-heart"></i></button>
    <button class="ek-quick-btn" data-share="<?= e(url('/ad/' . $a['slug'])) ?>" aria-label="Share"><i class="fa-solid fa-share-nodes"></i></button>
  </div>
  <div class="body">
    <a class="title" href="<?= url('/ad/' . $a['slug']) ?>"><?= e($a['title']) ?></a>
    <div class="ek-price"><?= (float)$a['price'] > 0 ? money($a['price']) : 'Contact for price' ?><?php if (!empty($a['negotiable'])): ?><span class="old" style="text-decoration:none"> (Negotiable)</span><?php endif; ?></div>
    <div class="meta">
      <span><i class="fa-solid fa-location-dot"></i> <?= e(trim(($a['area'] ? $a['area'] . ', ' : '') . ($a['city_name'] ?? ''))) ?></span>
      <span class="ms-auto"><i class="fa-regular fa-clock"></i> <?= e(time_ago($a['created_at'])) ?></span>
    </div>
  </div>
</article>
