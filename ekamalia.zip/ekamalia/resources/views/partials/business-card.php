<?php /** Business directory card. Expects $b */ ?>
<article class="ek-card ek-biz-card reveal in">
  <img class="logo" src="<?= e(img_or($b['logo'] ?? '', 'assets/img/biz-logo.svg')) ?>" alt="<?= e($b['name']) ?>" loading="lazy">
  <div class="flex-grow-1 min-w-0">
    <a class="fw-bold d-block text-truncate" href="<?= url('/business/' . $b['slug']) ?>"><?= e($b['name']) ?>
      <?php if ($b['is_verified']): ?><i class="fa-solid fa-circle-check verified-tick"></i><?php endif; ?>
    </a>
    <div class="d-flex align-items-center gap-2 flex-wrap" style="font-size:.76rem;color:var(--ek-muted)">
      <?php if (!empty($b['cat_name'])): ?><span><i class="fa-solid fa-briefcase me-1"></i><?= e($b['cat_name']) ?></span><?php endif; ?>
      <?php if (!empty($b['area']) || !empty($b['city_name'])): ?><span><i class="fa-solid fa-location-dot me-1"></i><?= e(trim(($b['area'] ? $b['area'] . ', ' : '') . ($b['city_name'] ?? ''))) ?></span><?php endif; ?>
    </div>
    <?php if ((int)$b['rating_count'] > 0): ?>
      <div class="stars mt-1">
        <?php for ($i = 1; $i <= 5; $i++): ?><i class="fa-<?= $i <= round((float)$b['rating_avg']) ? 'solid' : 'regular' ?> fa-star<?= $i <= round((float)$b['rating_avg']) ? '' : ' off' ?>"></i><?php endfor; ?>
        <span class="text-muted ms-1">(<?= (int)$b['rating_count'] ?>)</span>
      </div>
    <?php endif; ?>
  </div>
  <div class="d-flex flex-column gap-2">
    <?php if ($b['phone']): ?><a class="btn btn-sm btn-ek rounded-pill px-3" href="tel:<?= e($b['phone']) ?>"><i class="fa-solid fa-phone"></i></a><?php endif; ?>
    <?php if ($b['whatsapp']): ?><a class="btn btn-sm btn-outline-success rounded-pill px-3" target="_blank" rel="noopener" href="<?= e(wa_link($b['whatsapp'], 'Hello ' . $b['name'])) ?>"><i class="fa-brands fa-whatsapp"></i></a><?php endif; ?>
  </div>
</article>
