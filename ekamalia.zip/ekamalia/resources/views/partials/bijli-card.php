<?php
/**
 * Bijli feeder status card. Expects $f = [
 *   id,name,area,city_name,status,started_at,expected_at,message, since_txt
 * ]
 */
$map = ['on' => ['Supply ON', 'fa-lightbulb', 'on'], 'off' => ['Power OFF', 'fa-plug-circle-xmark', 'off'],
        'maintenance' => ['Maintenance', 'fa-screwdriver-wrench', 'maintenance'], 'scheduled' => ['Scheduled', 'fa-clock', 'scheduled']];
[$label, $icon, $cls] = $map[$f['status']] ?? $map['on'];
?>
<div class="bijli-card">
  <div class="bijli-orb <?= $cls ?>"><i class="fa-solid <?= $icon ?>"></i></div>
  <div class="flex-grow-1 min-w-0">
    <div class="fw-bold text-truncate"><?= e($f['name']) ?></div>
    <div class="text-muted text-truncate" style="font-size:.76rem"><i class="fa-solid fa-location-dot me-1"></i><?= e($f['area'] ?: $f['city_name']) ?></div>
    <div class="bijli-status <?= $cls ?> mt-1" style="font-size:.82rem">
      <?= $label ?>
      <?php if ($f['status'] === 'off' && $f['started_at']): ?>
        <span class="text-muted fw-normal">— <?= e(t('bijli.since')) ?> <?= e(time_ago($f['started_at'])) ?></span>
      <?php elseif ($f['status'] !== 'on' && $f['expected_at']): ?>
        <span class="text-muted fw-normal">— <?= e(t('bijli.expected')) ?>: <?= e(fmt_date($f['expected_at'], 'h:i A')) ?></span>
      <?php endif; ?>
    </div>
    <?php if (!empty($f['message']) && $f['status'] !== 'on'): ?>
      <div class="text-muted mt-1" style="font-size:.74rem;line-height:1.5"><?= e($f['message']) ?></div>
    <?php endif; ?>
  </div>
  <div class="text-end">
    <div class="text-muted" style="font-size:.68rem"><?= e(t('bijli.last')) ?></div>
    <div style="font-size:.76rem"><?= e(time_ago($f['last_update'] ?? null)) ?></div>
    <a class="btn btn-sm btn-link p-0 mt-1" style="font-size:.7rem" href="<?= url('/bijli?feeder=' . $f['id']) ?>">History</a>
  </div>
</div>
