<?php
/** Footer */
$siteName = setting('site_name', 'eKamalia');
?>
<footer class="ek-footer pt-5">
  <div class="container">
    <div class="row g-4 pb-4">
      <div class="col-lg-4 col-md-6">
        <div class="ek-logo mb-3" style="background:none;-webkit-text-fill-color:#fff;color:#fff"><i class="fa-solid fa-store" style="color:var(--ek-gold)"></i> <?= e($siteName) ?></div>
        <p style="font-size:.88rem;max-width:340px"><?= e(t('footer.about')) ?></p>
        <div class="mt-3">
          <?php if (setting('social_fb')): ?><a class="social-round" href="<?= e(setting('social_fb')) ?>" target="_blank" rel="noopener" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a><?php endif; ?>
          <?php if (setting('social_ig')): ?><a class="social-round" href="<?= e(setting('social_ig')) ?>" target="_blank" rel="noopener" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a><?php endif; ?>
          <?php if (setting('social_x')): ?><a class="social-round" href="<?= e(setting('social_x')) ?>" target="_blank" rel="noopener" aria-label="X"><i class="fa-brands fa-x-twitter"></i></a><?php endif; ?>
          <?php if (setting('social_yt')): ?><a class="social-round" href="<?= e(setting('social_yt')) ?>" target="_blank" rel="noopener" aria-label="YouTube"><i class="fa-brands fa-youtube"></i></a><?php endif; ?>
          <?php if (setting('whatsapp_number')): ?><a class="social-round" href="<?= e(wa_link(setting('whatsapp_number'), 'Hello ' . $siteName . '!')) ?>" target="_blank" rel="noopener" aria-label="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a><?php endif; ?>
        </div>
      </div>
      <div class="col-lg-2 col-6">
        <h6><?= e(t('footer.links')) ?></h6>
        <a href="<?= url('/products') ?>">Products</a><br>
        <a href="<?= url('/ads') ?>">Classified Ads</a><br>
        <a href="<?= url('/shops') ?>">Shops</a><br>
        <a href="<?= url('/businesses') ?>">Business Directory</a><br>
        <a href="<?= url('/deals') ?>">Deals & Coupons</a><br>
        <a href="<?= url('/news') ?>">Kamalia News</a>
      </div>
      <div class="col-lg-3 col-6">
        <h6>Kamalia Services</h6>
        <a href="<?= url('/bijli') ?>"><i class="fa-solid fa-bolt me-1 text-warning"></i> Bijli Updates</a><br>
        <a href="<?= url('/explore-kamalia') ?>">Explore Kamalia</a><br>
        <a href="<?= url('/shops/create') ?>">Create Your Shop</a><br>
        <a href="<?= url('/pos/request') ?>">Premium POS</a><br>
        <a href="<?= url('/categories') ?>">All Categories</a><br>
        <a href="<?= url('/cities') ?>">All Cities</a>
      </div>
      <div class="col-lg-3">
        <h6><?= e(t('footer.support')) ?></h6>
        <?php foreach ($footerPages as $p): ?>
          <a href="<?= url('/page/' . $p['slug']) ?>"><?= e($p['title']) ?></a><br>
        <?php endforeach; ?>
        <a href="<?= url('/contact') ?>">Contact Us</a>
      </div>
    </div>
    <div class="f-bottom d-flex flex-wrap justify-content-between align-items-center gap-2 py-3">
      <span>© <?= date('Y') ?> <?= e($siteName) ?>. <?= e(t('footer.rights')) ?></span>
      <span class="d-flex align-items-center gap-3">
        <span><i class="fa-solid fa-location-dot me-1"></i> Kamalia, Toba Tek Singh, Punjab 🇵🇰</span>
        <button class="chip border-0" data-lang="en">EN</button>
        <button class="chip border-0" data-lang="ur">اردو</button>
      </span>
    </div>
  </div>
</footer>
