<?php
/** Mobile bottom navigation */
$auth = (isset($auth) && $auth) ? $auth : auth();
$p = current_path();
$active = fn($prefix) => str_starts_with($p, $prefix) ? ' active' : '';
?>
<nav class="mobile-nav" aria-label="Mobile navigation">
  <a href="<?= url('/') ?>" class="<?= $p === '/' ? 'active' : '' ?>"><i class="fa-solid fa-house"></i>Home</a>
  <a href="<?= url('/categories') ?>" class="<?= $active('/category') . $active('/categories') ?>"><i class="fa-solid fa-grip"></i>Categories</a>
  <a href="<?= url('/ads/create') ?>" class="post-fab" aria-label="Post ad"><i class="fa-solid fa-plus"></i></a>
  <a href="<?= url('/messages') ?>" class="<?= $active('/messages') . $active('/chat') ?>"><i class="fa-regular fa-comment-dots"></i>Messages</a>
  <a href="<?= url($auth ? '/dashboard' : '/login') ?>" class="<?= $active('/dashboard') . $active('/login') . $active('/profile') ?>"><i class="fa-regular fa-user"></i>Account</a>
</nav>
