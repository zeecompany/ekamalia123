<?php
/** Header: desktop + mobile */
$me = auth();
$locSel = $_GET['city'] ?? ($_SESSION['loc_city'] ?? '');
?>
<header class="ek-header">
  <nav class="navbar navbar-expand-lg">
    <div class="container">
      <!-- mobile: hamburger -->
      <button class="ek-icon-btn d-lg-none" onclick="ekDrawer(true)" aria-label="Open menu"><i class="fa-solid fa-bars"></i></button>

      <a class="ek-logo me-lg-3" href="<?= url('/') ?>" aria-label="eKamalia home">
        <i class="fa-solid fa-store"></i><span>eKamalia</span>
      </a>

      <!-- search (desktop) -->
      <form class="ek-search-form d-none d-md-flex ms-lg-3" action="<?= url('/search') ?>" method="get" role="search">
        <input type="text" id="globalSearch" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="<?= e(t('search.placeholder')) ?>" aria-label="Search">
        <select class="loc-select" name="city" aria-label="Location">
          <option value=""><?= e(t('search.anywhere')) ?></option>
          <?php foreach ($citiesTop as $c): ?>
            <option value="<?= e($c['slug']) ?>" <?= $locSel === $c['slug'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit" aria-label="Search"><i class="fa-solid fa-magnifying-glass"></i></button>
        <div class="ek-search-suggest" id="searchSuggest"></div>
      </form>

      <div class="ek-actions ms-auto">
        <a class="ek-btn-post d-none d-lg-inline-flex" href="<?= url('/ads/create') ?>"><i class="fa-solid fa-plus me-1"></i> <?= e(t('nav.post_ad')) ?></a>

        <?php if ($me): ?>
          <a class="ek-icon-btn" href="<?= url('/messages') ?>" aria-label="Messages">
            <i class="fa-regular fa-comment-dots"></i>
            <span class="ek-badge-dot" id="msgBadge" style="display:none">0</span>
          </a>
          <button class="ek-icon-btn" data-dd="ddNotif" aria-label="Notifications">
            <i class="fa-regular fa-bell"></i>
            <span class="ek-badge-dot" data-notif-badge style="display:none">0</span>
          </button>
        <?php endif; ?>
        <a class="ek-icon-btn" href="<?= url('/wishlist') ?>" aria-label="Wishlist"><i class="fa-regular fa-heart"></i></a>
        <a class="ek-icon-btn" href="<?= url('/cart') ?>" aria-label="Cart">
          <i class="fa-solid fa-basket-shopping"></i>
          <span class="ek-badge-dot" data-cart-badge style="display:<?= $cartCount ? 'flex' : 'none' ?>"><?= $cartCount ?></span>
        </a>

        <?php if ($me): ?>
          <div class="dropdown">
            <button class="btn p-0 border-0 d-flex align-items-center gap-2" data-bs-toggle="dropdown" aria-expanded="false">
              <img src="<?= $me['avatar'] ? upload_url($me['avatar']) : asset('img/avatar-default.svg') ?>" alt="" style="width:38px;height:38px;border-radius:50%;object-fit:cover" loading="lazy">
              <span class="d-none d-xl-inline fw-semibold small"><?= e(explode(' ', $me['name'])[0]) ?></span>
            </button>
            <div class="dropdown-menu dropdown-menu-end shadow border-0 rounded-4 p-2" style="min-width:230px">
              <div class="px-3 py-2">
                <div class="fw-bold small"><?= e($me['name']) ?></div>
                <div class="text-muted" style="font-size:.75rem"><?= e($me['email']) ?></div>
              </div>
              <hr class="my-1">
              <a class="dropdown-item rounded-3 py-2" href="<?= url('/dashboard') ?>"><i class="fa-solid fa-gauge-high me-2"></i><?= e(t('nav.dashboard')) ?></a>
              <a class="dropdown-item rounded-3 py-2" href="<?= url('/dashboard/orders') ?>"><i class="fa-solid fa-box me-2"></i><?= e(t('nav.my_orders')) ?></a>
              <a class="dropdown-item rounded-3 py-2" href="<?= url('/dashboard/my-ads') ?>"><i class="fa-solid fa-tag me-2"></i><?= e(t('nav.my_ads')) ?></a>
              <?php if ($myShopExists): ?>
                <a class="dropdown-item rounded-3 py-2" href="<?= url('/seller') ?>"><i class="fa-solid fa-store me-2"></i><?= e(t('nav.my_shop')) ?></a>
              <?php else: ?>
                <a class="dropdown-item rounded-3 py-2" href="<?= url('/shops/create') ?>"><i class="fa-solid fa-shop me-2"></i>Create Your Shop</a>
              <?php endif; ?>
              <?php if (pos_access()): ?>
                <a class="dropdown-item rounded-3 py-2" href="<?= url('/pos') ?>"><i class="fa-solid fa-cash-register me-2"></i><?= e(t('nav.pos')) ?></a>
              <?php endif; ?>
              <?php if ($me['role'] === 'admin'): ?>
                <a class="dropdown-item rounded-3 py-2 text-success fw-bold" href="<?= url('/admin') ?>"><i class="fa-solid fa-user-shield me-2"></i><?= e(t('nav.admin')) ?></a>
              <?php endif; ?>
              <hr class="my-1">
              <a class="dropdown-item rounded-3 py-2 text-danger" href="<?= url('/logout') ?>"><i class="fa-solid fa-right-from-bracket me-2"></i><?= e(t('nav.logout')) ?></a>
            </div>
          </div>
        <?php else: ?>
          <a class="ek-icon-btn" href="<?= url('/login') ?>" aria-label="Login"><i class="fa-regular fa-user"></i></a>
          <a class="btn btn-outline-success d-none d-sm-inline-flex rounded-pill px-3 fw-semibold" href="<?= url('/register') ?>"><?= e(t('nav.register')) ?></a>
        <?php endif; ?>
      </div>
    </div>
  </nav>

  <!-- search mobile -->
  <div class="container d-md-none pb-2">
    <form class="ek-search-form" action="<?= url('/search') ?>" method="get" role="search">
      <input type="text" id="globalSearchM" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Search eKamalia…" aria-label="Search">
      <input type="hidden" name="city" value="<?= e($locSel) ?>">
      <button type="submit" aria-label="Search"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
  </div>

  <!-- category nav -->
  <div class="ek-catnav d-none d-lg-block">
    <div class="container">
      <div class="scroller">
        <a href="<?= url('/categories') ?>" class="fw-bold"><i class="fa-solid fa-grip"></i> All Categories</a>
        <a href="<?= url('/bijli') ?>"><i class="fa-solid fa-bolt text-warning"></i> Bijli Updates</a>
        <a href="<?= url('/shops') ?>"><i class="fa-solid fa-store"></i> Shops</a>
        <a href="<?= url('/businesses') ?>"><i class="fa-solid fa-map-location-dot"></i> Directory</a>
        <a href="<?= url('/deals') ?>"><i class="fa-solid fa-percent"></i> Deals</a>
        <?php foreach ($mainCats as $c): ?>
          <a href="<?= url('/category/' . $c['slug']) ?>"><i class="fa-solid <?= e($c['icon'] ?: 'fa-tag') ?>"></i> <?= e($c['name']) ?></a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- notifications dropdown -->
  <?php if ($me): ?>
  <div class="ek-dropdown" id="ddNotif">
    <div class="dd-head">Notifications <a href="<?= url('/notifications') ?>" class="small">View all</a></div>
    <div class="dd-body" id="notifList"><div class="p-3 text-center text-muted small">Loading…</div></div>
  </div>
  <?php endif; ?>
</header>

<!-- mobile drawer -->
<div class="ek-drawer-backdrop" id="ekDrawerBackdrop"></div>
<aside class="ek-drawer" id="ekDrawer" aria-label="Menu">
  <div class="dw-head">
    <div class="d-flex justify-content-between align-items-center">
      <span class="ek-logo" style="color:#fff;background:none;-webkit-text-fill-color:#fff"><i class="fa-solid fa-store" style="color:var(--ek-gold)"></i> eKamalia</span>
      <button class="btn text-white" onclick="ekDrawer(false)" aria-label="Close menu"><i class="fa-solid fa-xmark"></i></button>
    </div>
    <?php if ($me): ?>
      <div class="d-flex align-items-center gap-2 mt-3">
        <img src="<?= $me['avatar'] ? upload_url($me['avatar']) : asset('img/avatar-default.svg') ?>" style="width:44px;height:44px;border-radius:50%;object-fit:cover" alt="">
        <div><div class="fw-bold small"><?= e($me['name']) ?></div><div style="font-size:.72rem;opacity:.8"><?= e($me['phone'] ?: $me['email']) ?></div></div>
      </div>
    <?php else: ?>
      <div class="d-grid gap-2 mt-3">
        <a href="<?= url('/login') ?>" class="btn btn-light btn-sm rounded-pill fw-semibold">Login</a>
        <a href="<?= url('/register') ?>" class="btn btn-outline-light btn-sm rounded-pill">Register</a>
      </div>
    <?php endif; ?>
  </div>
  <nav>
    <a class="dw-link" href="<?= url('/') ?>"><i class="fa-solid fa-house w-4"></i> <?= e(t('nav.home')) ?></a>
    <a class="dw-link" href="<?= url('/categories') ?>"><i class="fa-solid fa-grip w-4"></i> <?= e(t('nav.categories')) ?></a>
    <a class="dw-link fw-bold" href="<?= url('/ads/create') ?>"><i class="fa-solid fa-circle-plus w-4 text-success"></i> <?= e(t('nav.post_ad')) ?></a>
    <a class="dw-link" href="<?= url('/products') ?>"><i class="fa-solid fa-bag-shopping w-4"></i> <?= e(t('nav.products')) ?></a>
    <a class="dw-link" href="<?= url('/ads') ?>"><i class="fa-solid fa-tag w-4"></i> <?= e(t('nav.ads')) ?></a>
    <a class="dw-link" href="<?= url('/shops') ?>"><i class="fa-solid fa-store w-4"></i> <?= e(t('nav.shops')) ?></a>
    <a class="dw-link" href="<?= url('/businesses') ?>"><i class="fa-solid fa-map-location-dot w-4"></i> <?= e(t('nav.businesses')) ?></a>
    <a class="dw-link" href="<?= url('/bijli') ?>"><i class="fa-solid fa-bolt w-4 text-warning"></i> <?= e(t('nav.bijli')) ?></a>
    <a class="dw-link" href="<?= url('/deals') ?>"><i class="fa-solid fa-percent w-4"></i> Deals</a>
    <a class="dw-link" href="<?= url('/news') ?>"><i class="fa-solid fa-newspaper w-4"></i> <?= e(t('nav.news')) ?></a>
    <a class="dw-link" href="<?= url('/explore-kamalia') ?>"><i class="fa-solid fa-city w-4"></i> <?= e(t('nav.explore')) ?></a>
    <a class="dw-link" href="<?= url('/contact') ?>"><i class="fa-solid fa-headset w-4"></i> <?= e(t('nav.contact')) ?></a>
    <hr class="my-1">
    <?php if ($me): ?>
      <a class="dw-link" href="<?= url('/dashboard') ?>"><i class="fa-solid fa-gauge-high w-4"></i> <?= e(t('nav.dashboard')) ?></a>
      <a class="dw-link" href="<?= url('/dashboard/my-ads') ?>"><i class="fa-solid fa-tag w-4"></i> <?= e(t('nav.my_ads')) ?></a>
      <?php if ($myShopExists): ?><a class="dw-link" href="<?= url('/seller') ?>"><i class="fa-solid fa-shop w-4"></i> <?= e(t('nav.my_shop')) ?></a>
      <?php else: ?><a class="dw-link" href="<?= url('/shops/create') ?>"><i class="fa-solid fa-shop w-4 text-success"></i> Create Shop</a><?php endif; ?>
      <?php if (pos_access()): ?><a class="dw-link" href="<?= url('/pos') ?>"><i class="fa-solid fa-cash-register w-4"></i> POS Terminal</a><?php endif; ?>
      <a class="dw-link text-danger" href="<?= url('/logout') ?>"><i class="fa-solid fa-right-from-bracket w-4"></i> <?= e(t('nav.logout')) ?></a>
    <?php endif; ?>
    <div class="p-3 d-flex gap-2 small">
      <button class="chip <?= lang() === 'en' ? 'active' : '' ?>" data-lang="en">English</button>
      <button class="chip <?= lang() === 'ur' ? 'active' : '' ?>" data-lang="ur">اردو</button>
    </div>
  </nav>
</aside>
