<?php /** Shop card. Expects $s */ ?>
<article class="ek-card ek-shop-card">
  <div class="cover"><img src="<?= e(img_or($s['cover'] ?? '', 'assets/img/shop-cover.svg')) ?>" alt="" loading="lazy" data-fade></div>
  <img class="logo" src="<?= e(img_or($s['logo'] ?? '', 'assets/img/shop-logo.svg')) ?>" alt="<?= e($s['name']) ?>" loading="lazy">
  <div class="body">
    <a class="fw-bold text-truncate d-block" href="<?= url('/shop/' . $s['slug']) ?>"><?= e($s['name']) ?>
      <?php if ($s['is_verified']): ?><i class="fa-solid fa-circle-check verified-tick"></i><?php endif; ?>
    </a>
    <div class="text-muted" style="font-size:.75rem"><?= e(t('shop.owner')) ?>: <?= e($s['owner_name'] ?: '—') ?></div>
    <div class="stats">
      <span><b><?= number_format((int)qv('SELECT COUNT(*) FROM products WHERE shop_id=? AND status="published"', [$s['id']])) ?></b> Products</span>
      <span><i class="fa-solid fa-star" style="color:#f5b301"></i> <b><?= number_format((float)$s['rating_avg'], 1) ?></b></span>
      <span><b><?= number_format((int)$s['followers_count']) ?></b> Followers</span>
    </div>
    <div class="d-flex gap-2 justify-content-center">
      <a class="btn btn-ek btn-sm rounded-pill px-3" href="<?= url('/shop/' . $s['slug']) ?>"><?= e(t('btn.visit_shop')) ?></a>
      <button class="btn btn-sm rounded-pill px-3 <?= !empty($s['following']) ? 'btn-outline-success' : 'btn-outline-dark' ?>" data-follow="<?= $s['id'] ?>">
        <?= !empty($s['following']) ? '<i class="fa-solid fa-check me-1"></i>Following' : '<i class="fa-solid fa-plus me-1"></i>Follow' ?>
      </button>
    </div>
  </div>
</article>
