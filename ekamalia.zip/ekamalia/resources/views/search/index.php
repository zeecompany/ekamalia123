<div class="container py-4">
  <h1 class="h4 fw-bold mb-1">Search eKamalia</h1>
  <form class="row g-2 mb-4" method="get">
    <div class="col-md-4"><input class="form-control form-control-lg" name="q" value="<?= e($q) ?>" placeholder="Search products, ads, shops, businesses…"></div>
    <div class="col-md-3"><select class="form-select form-select-lg" name="type">
      <?php foreach (['all' => 'Everything', 'products' => 'Products', 'ads' => 'Classified Ads', 'shops' => 'Shops', 'businesses' => 'Businesses'] as $k => $v): ?>
        <option value="<?= $k ?>" <?= $type === $k ? 'selected' : '' ?>><?= $v ?></option>
      <?php endforeach; ?></select></div>
    <div class="col-md-3"><select class="form-select form-select-lg" name="city"><option value="">All cities</option>
      <?php foreach ($cities as $c): ?><option value="<?= e($c['slug']) ?>" <?= ($_GET['city'] ?? '') === $c['slug'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-2"><button class="btn btn-ek btn-lg w-100 rounded-pill"><i class="fa-solid fa-magnifying-glass"></i></button></div>
  </form>

  <?php if ($q !== '' || input('city') || input('cat')): ?>
    <?php if ($total === 0): ?>
      <div class="ek-empty"><i class="fa-regular fa-face-frown"></i><h5>No results for "<?= e($q) ?>"</h5>
        <p class="small">Try different keywords or browse the <a href="<?= url('/categories') ?>">categories</a>.</p></div>
    <?php else: ?>
      <p class="text-muted small"><?= number_format($total) ?> results</p>
      <?php if ($products): ?><h5 class="fw-bold mt-3"><i class="fa-solid fa-bag-shopping me-1 text-success"></i>Products</h5>
      <div class="row g-3 row-cols-2 row-cols-md-4"><?php foreach ($products as $p): ?><div class="col"><?php include views_path('partials/product-card'); ?></div><?php endforeach; ?></div><?php endif; ?>
      <?php if ($ads): ?><h5 class="fw-bold mt-4"><i class="fa-solid fa-tag me-1 text-success"></i>Classified Ads</h5>
      <div class="row g-3 row-cols-2 row-cols-md-4"><?php foreach ($ads as $a): ?><div class="col"><?php include views_path('partials/ad-card'); ?></div><?php endforeach; ?></div><?php endif; ?>
      <?php if ($shops): ?><h5 class="fw-bold mt-4"><i class="fa-solid fa-store me-1 text-success"></i>Shops</h5>
      <div class="row g-4 row-cols-1 row-cols-sm-2 row-cols-lg-4"><?php foreach ($shops as $s): ?><div class="col"><?php include views_path('partials/shop-card'); ?></div><?php endforeach; ?></div><?php endif; ?>
      <?php if ($businesses): ?><h5 class="fw-bold mt-4"><i class="fa-solid fa-briefcase me-1 text-success"></i>Businesses</h5>
      <div class="row g-3"><?php foreach ($businesses as $b): ?><div class="col-md-6"><?php include views_path('partials/business-card'); ?></div><?php endforeach; ?></div><?php endif; ?>
      <?php if (auth()): ?>
      <form class="mt-4 text-center" method="post" action="<?= url('/search/save') ?>"><?= csrf_field() ?>
        <input type="hidden" name="name" value="<?= e($q ?: 'My search') ?>">
        <button class="btn btn-outline-success rounded-pill px-4 btn-sm"><i class="fa-regular fa-bell me-1"></i>Save this search &amp; get alerts</button>
      </form>
      <?php endif; ?>
    <?php endif; ?>
  <?php else: ?>
    <h5 class="fw-bold text-muted mb-3">Popular Categories</h5>
    <div class="row g-2 row-cols-3 row-cols-md-5">
      <?php foreach (array_slice($cats, 0, 10) as $c): ?>
        <a class="col ek-cat-card" href="<?= url('/category/' . $c['slug']) ?>"><div class="ic"><i class="fa-solid <?= e($c['icon'] ?: 'fa-tag') ?>"></i></div><div class="nm"><?= e($c['name']) ?></div></a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
