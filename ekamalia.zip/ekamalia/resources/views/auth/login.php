<div class="container py-5" style="max-width:460px">
  <div class="text-center mb-4">
    <a class="ek-logo" href="<?= url('/') ?>"><i class="fa-solid fa-store"></i> eKamalia</a>
    <h1 class="h5 mt-3 fw-bold"><?= e(t('auth.login')) ?></h1>
  </div>
  <form class="ek-card p-4" method="post" action="<?= url('/login') ?>">
    <?= csrf_field() ?>
    <div class="mb-3">
      <label class="form-label fw-semibold small"><?= e(t('auth.email')) ?></label>
      <input type="email" class="form-control form-control-lg" name="email" value="<?= old('email') ?>" required autofocus>
    </div>
    <div class="mb-2">
      <label class="form-label fw-semibold small"><?= e(t('auth.password')) ?></label>
      <input type="password" class="form-control form-control-lg" name="password" required>
    </div>
    <div class="d-flex justify-content-between align-items-center mb-3">
      <a class="small" href="<?= url('/forgot-password') ?>"><?= e(t('auth.forgot')) ?></a>
    </div>
    <button class="btn btn-ek w-100 btn-lg rounded-pill">Login <i class="fa-solid fa-arrow-right-to-bracket ms-1"></i></button>
    <div class="text-center mt-3 small">
      <?= e(t('auth.no_account')) ?> <a class="fw-bold text-success" href="<?= url('/register') ?>"><?= e(t('auth.register')) ?></a>
    </div>
  </form>
</div>
