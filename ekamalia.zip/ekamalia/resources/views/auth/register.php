<?php $cities = qa('SELECT * FROM cities WHERE is_active=1 ORDER BY is_primary DESC, sort_order'); ?>
<div class="container py-5" style="max-width:560px">
  <div class="text-center mb-4">
    <a class="ek-logo" href="<?= url('/') ?>"><i class="fa-solid fa-store"></i> eKamalia</a>
    <h1 class="h5 mt-3 fw-bold"><?= e(t('auth.register')) ?></h1>
    <p class="text-muted small">Join Kamalia's digital bazaar — it's free!</p>
  </div>
  <form class="ek-card p-4" method="post" action="<?= url('/register') ?>">
    <?= csrf_field() ?>
    <div class="row g-3">
      <div class="col-12">
        <label class="form-label fw-semibold small"><?= e(t('auth.name')) ?> *</label>
        <input type="text" class="form-control" name="name" value="<?= old('name') ?>" required maxlength="120">
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold small"><?= e(t('auth.email')) ?> *</label>
        <input type="email" class="form-control" name="email" value="<?= old('email') ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold small"><?= e(t('auth.phone')) ?></label>
        <input type="tel" class="form-control" name="phone" value="<?= old('phone') ?>" placeholder="03XX-XXXXXXX" pattern="[0-9+\-\s]{10,15}">
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold small">City</label>
        <select class="form-select" name="city_id">
          <option value="">Select city</option>
          <?php foreach ($cities as $c): ?><option value="<?= $c['id'] ?>" <?= old('city_id') == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold small"><?= e(t('auth.password')) ?> *</label>
        <input type="password" class="form-control" name="password" required minlength="8">
      </div>
      <div class="col-12">
        <label class="form-label fw-semibold small">Confirm Password *</label>
        <input type="password" class="form-control" name="password_confirmation" required minlength="8">
      </div>
    </div>
    <div class="form-check mt-3 small">
      <input class="form-check-input" type="checkbox" id="agree" required>
      <label class="form-check-label" for="agree">I agree to the <a href="<?= url('/page/terms') ?>" target="_blank">Terms</a> & <a href="<?= url('/page/privacy') ?>" target="_blank">Privacy Policy</a></label>
    </div>
    <button class="btn btn-ek w-100 btn-lg rounded-pill mt-3">Create Account <i class="fa-solid fa-user-plus ms-1"></i></button>
    <div class="text-center mt-3 small">
      <?= e(t('auth.have_account')) ?> <a class="fw-bold text-success" href="<?= url('/login') ?>"><?= e(t('auth.login')) ?></a>
    </div>
  </form>
</div>
